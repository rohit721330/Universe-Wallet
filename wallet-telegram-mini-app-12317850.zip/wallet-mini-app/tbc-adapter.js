/*
 * Secure TBC bridge adapter.
 *
 * This project deliberately does not call Telegram Bot API to read or change
 * balances. It must use a Telebot Creator webhook bridge that executes the
 * existing bot's TPY data logic for bot #12317850.
 *
 * Set TBC_BRIDGE_URL only after the bridge command is added and tested.
 * Set TBC_BRIDGE_SECRET to a long random secret shared by the server and
 * that bridge. Never put either value in browser code.
 */
import crypto from "node:crypto";

const bridgeUrl=process.env.TBC_BRIDGE_URL;
const bridgeSecret=process.env.TBC_BRIDGE_SECRET;

async function call({botId,action,initData,payload}){
  if(!bridgeUrl||!bridgeSecret) {
    const error=new Error("TBC bridge is not connected yet. The website UI is ready, but live bot data is intentionally not simulated.");
    error.status=503;throw error;
  }
  const body=JSON.stringify({bot_id:botId,action,initData,payload});
  const timestamp=String(Math.floor(Date.now()/1000));
  const signature=crypto.createHmac("sha256",bridgeSecret).update(timestamp+"."+body).digest("hex");
  const response=await fetch(bridgeUrl,{method:"POST",headers:{"Content-Type":"application/json","X-Wallet-Timestamp":timestamp,"X-Wallet-Signature":signature},body});
  const result=await response.json().catch(()=>({error:"Invalid TBC bridge response"}));
  if(!response.ok||result.ok===false){const error=new Error(result.error||"TBC bridge request failed");error.status=result.status||response.status||503;throw error}
  return result.data??result;
}
async function isAdmin(botId,initData){
  const result=await call({botId,action:"auth.is_admin",initData,payload:{}});
  return result.is_admin===true;
}
export const tbc={call,isAdmin};