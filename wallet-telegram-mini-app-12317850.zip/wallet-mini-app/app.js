const tg = window.Telegram?.WebApp;
const $ = (id) => document.getElementById(id);
const state = { user: null, data: null, tab: "home" };
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function money(value){const n=Number(value||0);return n.toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}
async function api(path, body={}) {
  const response = await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({initData:tg?.initData||"",...body})});
  const result = await response.json().catch(()=>({error:"Invalid server response"}));
  if(!response.ok) throw new Error(result.error||"Request failed");
  return result;
}
function setTab(tab){
  state.tab=tab;
  ["home","refer","gift","withdraw"].forEach(name=>{
    const panel=$(name==="home"?"homeSummary":name+"Panel");
    if(panel) panel.classList.toggle("hidden",name!==tab);
  });
  document.querySelectorAll(".nav-item").forEach(btn=>btn.classList.toggle("active",btn.dataset.tab===tab));
  if(tab==="withdraw" && state.data) $("withdrawBalance").textContent="₹"+money(state.data.balance);
}
function applyData(data){
  state.data=data;
  const user=data.user||{};
  $("welcomeName").textContent="Hi, "+(user.first_name||"there");
  $("telegramId").textContent="Telegram ID · "+user.id;
  $("avatar").textContent=(user.first_name||"U").slice(0,1).toUpperCase();
  $("balanceValue").textContent=money(data.balance);
  $("referralCount").textContent=data.referrals??0;
  $("referralCount2").textContent=data.referrals??0;
  $("walletValue").textContent=data.wallet_number||"Not linked";
  $("walletInput").value=data.wallet_number||"";
  $("withdrawState").textContent=data.withdraw_enabled?"Available":"Unavailable";
  $("accountState").textContent="Synced";
  $("refReward").textContent=data.referral_reward??"Configured in bot";
  $("refLink").textContent=data.referral_link||"Referral link unavailable";
  $("withdrawBalance").textContent="₹"+money(data.balance);
  const select=$("gatewaySelect");select.innerHTML="";
  (data.gateways||[]).forEach(g=>{const o=document.createElement("option");o.value=g.id;o.textContent=g.name;select.appendChild(o)});
  if(!select.options.length) select.innerHTML='<option value="">No active methods</option>';
  $("homeNotice").textContent=data.notice||"Your data is synced from the linked Telegram bot.";
}
async function load(){
  if(!tg?.initData){$("userApp").classList.add("hidden");$("bottomNav").classList.add("hidden");$("accessError").classList.remove("hidden");$("accessErrorText").textContent="Open this Mini App from the Telegram bot to securely identify your account.";return}
  tg.ready();tg.expand();
  try{const data=await api("/api/user/summary");applyData(data)}
  catch(e){$("accountState").textContent="Connection needed";$("homeNotice").textContent=e.message;toast(e.message)}
}
document.querySelectorAll("[data-tab]").forEach(btn=>btn.addEventListener("click",()=>setTab(btn.dataset.tab)));
$("refreshBtn").addEventListener("click",load);
$("copyRefBtn").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("refLink").textContent);toast("Referral link copied")}catch{toast("Copy is not available")}});
$("redeemGiftBtn").addEventListener("click",async()=>{const code=$("giftCode").value.trim();if(!code){$("giftMessage").textContent="Enter a gift code first.";return}try{const r=await api("/api/user/redeem",{code});$("giftMessage").textContent=r.message||"Gift code submitted.";await load()}catch(e){$("giftMessage").textContent=e.message}});
$("saveWalletBtn").addEventListener("click",async()=>{const wallet=$("walletInput").value.trim();if(!wallet){$("withdrawMessage").textContent="Enter a wallet first.";return}try{const r=await api("/api/user/wallet",{wallet});$("withdrawMessage").textContent=r.message||"Wallet saved.";await load()}catch(e){$("withdrawMessage").textContent=e.message}});
$("withdrawBtn").addEventListener("click",async()=>{const amount=Number($("withdrawAmount").value),gateway=$("gatewaySelect").value;if(!Number.isFinite(amount)||amount<=0){$("withdrawMessage").textContent="Enter a valid amount.";return}try{const r=await api("/api/user/withdraw",{amount,gateway});$("withdrawMessage").textContent=r.message||"Withdrawal request submitted."}catch(e){$("withdrawMessage").textContent=e.message}});
load();