import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { tbc } from "./tbc-adapter.js";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:"32kb"}));
app.use(express.static(path.join(__dirname,"public")));
const BOT_ID=process.env.TBC_BOT_ID||"12317850";
const PORT=Number(process.env.PORT||3000);
function auth(req,res,next){
  const initData=req.body?.initData;
  if(typeof initData!=="string"||!initData){return res.status(401).json({error:"Open this Mini App inside Telegram."})}
  req.initData=initData;
  next();
}
function admin(req,res,next){
  if(!req.initData)return res.status(401).json({error:"Authentication required"});
  tbc.isAdmin(BOT_ID,req.initData).then(ok=>ok?next():res.status(403).json({error:"Admin access denied"})).catch(e=>res.status(503).json({error:e.message}));
}
function run(action){return async(req,res)=>{try{const result=await tbc.call({botId:BOT_ID,action,initData:req.initData,payload:req.body||{}});res.json(result)}catch(e){res.status(e.status||503).json({error:e.message})}}}

app.post("/api/user/summary",auth,run("user.summary"));
app.post("/api/user/redeem",auth,run("user.redeem"));
app.post("/api/user/wallet",auth,run("user.wallet"));
app.post("/api/user/withdraw",auth,run("user.withdraw"));
app.post("/api/admin/summary",auth,admin,run("admin.summary"));
app.post("/api/admin/user",auth,admin,run("admin.user"));
app.get("/health",(req,res)=>res.json({ok:true,botId:BOT_ID,adapterConfigured:Boolean(process.env.TBC_BRIDGE_URL)}));
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
if(!process.env.VERCEL) app.listen(PORT,()=>console.log(`Wallet Mini App listening on ${PORT}`));
export default app;